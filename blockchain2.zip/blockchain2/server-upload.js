const express = require('express');
const multer = require( 'multer');
const uuid = require('uuid').v4;

//storage variable
const storage = multer.diskStorage({
    destination: (req,file,cb) => {
        cb(null, 'uploads');
    },
    filename: (req,file,cb)=>{
        const { originalname } = file;
        cb(null, originalname);
    }  
});
const upload = multer({storage});

//starting up app
const app = express();
//link to html 
app.use(express.static('public'));
//upload route
app.post('/upload', upload.array('file'),(req,res) => {
    return res.json({ status: 'GOOD', uploaded: req.files.length});
    //blockchin codes here
    //then....

});
 
app.listen(3001, () => console.log('App is running'));

